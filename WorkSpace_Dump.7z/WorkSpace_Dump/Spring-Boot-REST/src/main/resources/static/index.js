
// TODO: load the list of books from /api/books and display them in a grid.
// Allow the user to sort on each attribute.
$('#app > h1').text('App has loaded!');


function sortTable(n) {
  var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
  table = document.getElementById("bookListTable");
  switching = true;
  //Set the sorting direction to ascending:
  dir = "asc"; 
  /*Make a loop that will continue until
  no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.rows;
    /*Loop through all table rows (except the
    first, which contains table headers):*/
    for (i = 1; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
      one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[n];
      y = rows[i + 1].getElementsByTagName("TD")[n];
      /*check if the two rows should switch place,
      based on the direction, asc or desc:*/
      if (dir == "asc") {
        if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
          //if so, mark as a switch and break the loop:
          shouldSwitch= true;
          break;
        }
      } else if (dir == "desc") {
        if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
          //if so, mark as a switch and break the loop:
          shouldSwitch = true;
          break;
        }
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
      //Each time a switch is done, increase this count by 1:
      switchcount ++;      
    } else {
      /*If no switching has been done AND the direction is "asc",
      set the direction to "desc" and run the while loop again.*/
      if (switchcount == 0 && dir == "asc") {
        dir = "desc";
        switching = true;
      }
    }
  }
}


$( document ).ready(function() {
	
	// GET REQUEST
	$("#getAllBooks").click(function(event){
	console.log("Success: ");
		event.preventDefault();
		ajaxGet();
	});
	// DO GET
	
	function ajaxGet(){
		$.ajax({
			type : "GET",
			url : window.location + "/api/books/find",
			dataType: 'json',
			success: function(result){

				var headInfo = null;
					var trHTML = null;
					var headHtml = null;
					var backButtonDiv= null;
				
				headInfo = '<p align = "center"><strong>Click On table attribute to Sort the books View</strong></p>'
				trHTML = '';
				headHtml = '<tr><th onclick="sortTable(0)">Book ID</th><th onclick="sortTable(1)">Sequence</th><th onclick="sortTable(2)">Title</th><th onclick="sortTable(3)">Published Date</th><th onclick="sortTable(4)">Published Month</th><th onclick="sortTable(5)">Published Year</th></tr>';
				backButtonDiv= '<p align = "center"><strong>Click on Back Button to Go Home</strong></p><p align = "center"><input type = "button"   id = "getAllBooksHome"  value = "Back" onclick ="getAllBooksDivHideFunc()" ></input>';
				if(result.status == "Done"){
					for (i = 0; i < result.book.length; i++) {
                    
					            trHTML +=
                                    '<tr><td>'
                                    + result.book[i].id
                                    + '</td><td>'
                                    +result.book[i].sequence 
                                    + '</td><td>'
                                    + result.book[i].title
                                    + '</td><td>'
                                    + result.book[i].dayPublished 
                                    + '</td><td>'
                                    + result.book[i].monthPublished
                                    + '</td><td>'
                                    + result.book[i].yearPublished 
                                    + '</td></tr>';
					
					}
					$('#tableHeadingInfo').append(headInfo);
					$('#booksDataHdr').append(headHtml);
			        $('#booksData').append(trHTML);
			        $('#backButtonDiv').append(backButtonDiv);
					console.log("Success: ", result);
				}else{
					$("#showAllBooksTabDiv").html("<strong>Error</strong>");
					console.log("Fail: ", result);
				}
			},
			error : function(e) {
				$("#showAllBooksTabDiv").html("<strong>Error</strong>");
				console.log("ERROR: ", e);
			}
		});	
	}
	
})


function showHideDiv() {
    var x = document.getElementById("getAllBooksDiv");
    var y = document.getElementById("showAllBooksTabDiv");

    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
        y.style.display = "block";

    }
}


function getAllBooksDivHideFunc() {
    var x = document.getElementById("getAllBooksDiv");
    var y = document.getElementById("showAllBooksTabDiv");

    if (x.style.display === "none") {
        x.style.display = "block";
        y.style.display = "none";
    }
}



