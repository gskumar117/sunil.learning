package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories("com")

public class TestApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestApplication.class, args);
	}

	@Bean
	public CommandLineRunner setup(BookRepository bookRepository) {
		return (args) -> {
			bookRepository.save(new Book("Towers of Midnight", 2010, 11, 2, 13));
			bookRepository.save(new Book("The Dragon Reborn", 1991, 10, 15, 3));
			bookRepository.save(new Book("The Shadow Rising", 1992, 9, 15, 4));
			bookRepository.save(new Book("Knife of Dreams", 2005, 10, 11, 11));
			bookRepository.save(new Book("Eye of the World", 1990, 1, 15, 1));
			bookRepository.save(new Book("The Fires of Heaven", 1993, 10, 15, 5));
			bookRepository.save(new Book("A Crown of Swords", 1996, 5, 15, 7));
			bookRepository.save(new Book("The Path of Daggers", 1998, 10, 20, 8));
			bookRepository.save(new Book("Lord of Chaos", 1994, 10, 15, 6));
			bookRepository.save(new Book("A Memory of Light", 2013, 1, 8, 14));
			bookRepository.save(new Book("Winter's Heart", 2000, 11, 7, 9));
			bookRepository.save(new Book("Crossroads of Twilight", 2003, 1, 7, 10));
			bookRepository.save(new Book("New Spring", 2004, 1, 6, 0));
			bookRepository.save(new Book("The Gathering Storm", 2009, 10, 27, 12));
			bookRepository.save(new Book("The Great Hunt", 1990, 11, 15, 2));
		};
	}
}
