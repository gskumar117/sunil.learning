package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "BOOK")
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private Long id;
    @Column(name = "TITLE")
    private String title;
    @Column(name = "YEAR_PUBLISHED")
    private Integer yearPublished;
    @Column(name = "MONTH_PUBLISHED")
    private Integer monthPublished;
    @Column(name = "DAY_PUBLISHED")
    private Integer dayPublished;
    @Column(name = "SEQUENCE")
    private Integer sequence;

    
    
    public Book() {
    	// do - nothing Hibernate default constructor
    	super();
	}



	public Book(String title, Integer yearPublished, Integer monthPublished, Integer dayPublished, Integer sequence) {
        this.title = title;
        this.yearPublished = yearPublished;
        this.monthPublished = monthPublished;
        this.dayPublished = dayPublished;
        this.sequence = sequence;
    }



	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public String getTitle() {
		return title;
	}



	public void setTitle(String title) {
		this.title = title;
	}



	public Integer getYearPublished() {
		return yearPublished;
	}



	public void setYearPublished(Integer yearPublished) {
		this.yearPublished = yearPublished;
	}



	public Integer getMonthPublished() {
		return monthPublished;
	}



	public void setMonthPublished(Integer monthPublished) {
		this.monthPublished = monthPublished;
	}



	public Integer getDayPublished() {
		return dayPublished;
	}



	public void setDayPublished(Integer dayPublished) {
		this.dayPublished = dayPublished;
	}



	public Integer getSequence() {
		return sequence;
	}



	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}
	
	
	
}
