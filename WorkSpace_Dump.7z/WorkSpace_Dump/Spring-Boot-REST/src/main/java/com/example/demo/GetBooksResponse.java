package com.example.demo;

import java.util.List;

import lombok.Data;

@Data
public class GetBooksResponse {
    private List<Book> book;
    private String status;
    
    
	public GetBooksResponse(String status, List<Book> book) {
		this.status = status;
		this.book = book;
	}


	public List<Book> getBook() {
		return book;
	}


	public void setBook(List<Book> book) {
		this.book = book;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}
	    
}
